I = imread('image2.jpg');
compute_gradient(I);